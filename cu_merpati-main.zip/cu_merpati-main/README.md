# cu_merpati
Koperasi Simpan Pinjam
